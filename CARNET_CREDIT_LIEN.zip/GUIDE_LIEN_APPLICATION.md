# 🔗 METTRE L'APPLICATION EN LIGNE SOUS FORME DE LIEN (gratuit, permanent)

Vous allez obtenir **2 liens à partager** sur WhatsApp :

| Lien | Ce que ça fait |
|---|---|
| `https://mouafonmiguel-coder.github.io/carnet-credit/` | Le boutiquier **clique → l'app s'ouvre → il l'installe** (Chrome propose « Installer l'application » / « Ajouter à l'écran d'accueil ») |
| `https://mouafonmiguel-coder.github.io/carnet-credit.apk` | Le boutiquier **télécharge l'APK** et l'installe comme un fichier |

> ⏱ 10 minutes. Tout passe par votre site GitHub existant — 0 F de frais.

---

## PARTIE A — Le lien de l'application (à faire MAINTENANT)

1. Allez sur **github.com** et connectez-vous.
2. Ouvrez votre dépôt **mouafonmiguel-coder.github.io** (celui de votre site).
3. Cliquez **Add file** → **Upload files**.
4. Ouvrez le zip **CARNET_CREDIT_LIEN.zip** sur votre ordinateur → dedans il y a un dossier **carnet-credit**.
5. **Glissez le dossier `carnet-credit` EN ENTIER** dans la page GitHub (le dossier, pas son contenu — pour que GitHub crée `carnet-credit/...`).
   - Vérifiez dans la liste que les fichiers apparaissent comme `carnet-credit/index.html`, `carnet-credit/sw.js`, etc.
6. Bouton vert **Commit changes**.
7. Attendez **2 minutes**, puis ouvrez sur votre téléphone :
   **https://mouafonmiguel-coder.github.io/carnet-credit/**
8. Chrome affiche l'application → menu ⋮ → **« Installer l'application »** (ou « Ajouter à l'écran d'accueil ») → l'icône verte 📒 arrive sur l'écran d'accueil. **Après la première visite, elle marche MÊME SANS INTERNET.** ✅

## PARTIE B — Le lien de l'APK (après la fabrication GitHub Actions)

1. Fabriquez d'abord l'APK avec le guide **GUIDE_FABRIQUER_APK.md** (dépôt carnet-credit-apk → onglet Actions → Artifacts → **app-debug.apk**).
2. Sur votre ordinateur, **renommez** `app-debug.apk` en **`carnet-credit.apk`**.
3. Retournez dans le dépôt **mouafonmiguel-coder.github.io** → **Add file → Upload files** → glissez **carnet-credit.apk** → **Commit changes**.
4. Attendez 2 minutes. Votre lien APK est prêt :
   **https://mouafonmiguel-coder.github.io/carnet-credit.apk**

## 📣 Votre message de publicité WhatsApp (prêt à copier)

> 📒 *CARNET CRÉDIT — fini le cahier de dettes !*
> Notez les crédits de vos clients, envoyez des rappels WhatsApp en 1 clic, suivez votre caisse.
> ✅ 30 jours GRATUITS, puis 500 F/mois seulement.
>
> 👉 Installer l'application : https://mouafonmiguel-coder.github.io/carnet-credit/
> 👉 Ou télécharger l'APK : https://mouafonmiguel-coder.github.io/carnet-credit.apk
>
> Questions ? MIGUEL — 692 168 264

## ❓ Les deux liens donnent la MÊME application

- Les données restent **dans le téléphone** du boutiquier (lien comme APK).
- Les codes d'activation 🔑, le parrainage, la sauvegarde 💾 marchent pareil dans les deux.
- Différence : le lien = installation en 2 clics via Chrome ; l'APK = vraie application installée par fichier.
- ⚠️ Prévenez le boutiquier : s'il **efface les données de Chrome** (version lien) ou **désinstalle l'app** (version APK), son carnet est perdu → d'où la **sauvegarde WhatsApp** 💾 (page Guide, en bas).

## 🔄 Mises à jour plus tard

Quand je vous donne une nouvelle version : re-glissez le dossier `carnet-credit` dans le dépôt (GitHub remplace les fichiers) → tous les boutiquiers qui ouvrent l'app avec internet reçoivent la mise à jour automatiquement. Leurs données sont conservées. ✔
